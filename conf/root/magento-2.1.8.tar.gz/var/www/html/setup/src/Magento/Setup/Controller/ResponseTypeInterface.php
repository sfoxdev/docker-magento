<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Setup\Controller;

interface ResponseTypeInterface
{
    /**#@+
     * Response Type values
     */
    const RESPONSE_TYPE_SUCCESS = 'success';
    const RESPONSE_TYPE_ERROR = 'error';
    /**#@-*/
}
